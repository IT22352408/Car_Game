package com.example.car_gama_mad

interface GameTask {

    fun closeGame(mScore:Int)
}